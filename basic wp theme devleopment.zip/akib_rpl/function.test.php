<!DOCTYPE html>
<html lang="en">

<head>
    
</head>

<body
    class="home page-template page-template-home page-template-home-php page page-id-9 logged-in admin-bar no-customize-support custom-background wp-custom-logo">
    <div class="content_wrap container">
        <div class="header">
            <div class="top_header">
                <div id="top_header_container" class="container">
                    <div class="row justify-content-between">
                        <div class="p-1">
                            <p>Bangladesh National Portal</p>
                        </div>
                        <div class="d-flex p-1">
                            <p>8 March, 2022 |</p> &nbsp;
                            <p> English</p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="mid_header">
                <div class="container">
                    <div class="row justify-content-end">
                        <div class="col-4 pt-2 pl-4">
                            <a href="">
                                <a href="http://localhost/projects/RPL/" class="custom-logo-link" rel="home"
                                    aria-current="page"><img width="293" height="74"
                                        src="http://localhost/projects/RPL/wp-content/uploads/2022/02/logo_bn.png"
                                        class="custom-logo" alt="গণপ্রজাতন্ত্রী বাংলাদেশ" /></a> </a>
                        </div>
                        <div class="col-8 p-0">
                            <div class="d-flex justify-content-end">
                                <ul class="d-flex">
                                    <li>
                                        <a class="d-flex" href="#">
                                            <span>
                                                58
                                            </span>
                                            <span>
                                                Ministries <br>
                                                &amp;
                                                Divisions
                                            </span>
                                        </a>
                                    </li>
                                    <li>
                                        <a class="d-flex" href="#">
                                            <span>
                                                58
                                            </span>
                                            <span>
                                                Ministries <br>
                                                &amp;
                                                Divisions
                                            </span>
                                        </a>
                                    </li>
                                    <li>
                                        <a class="d-flex" href="#">
                                            <span>
                                                58
                                            </span>
                                            <span>
                                                Ministries <br>
                                                &amp;
                                                Divisions
                                            </span>
                                        </a>
                                    </li>
                                    <li>
                                        <a class="d-flex" href="#">
                                            <span>
                                                58
                                            </span>
                                            <span>
                                                Ministries <br>
                                                &amp;
                                                Divisions
                                            </span>
                                        </a>
                                    </li>
                                    <li>
                                        <a class="d-flex" href="#">
                                            <span>
                                                58
                                            </span>
                                            <span>
                                                Ministries <br>
                                                &amp;
                                                Divisions
                                            </span>
                                        </a>
                                    </li>
                                    <li>
                                        <a class="d-flex" href="#">
                                            <span>
                                                58
                                            </span>
                                            <span>
                                                Ministries <br>
                                                &amp;
                                                Divisions
                                            </span>
                                        </a>
                                    </li>
                                </ul>
                            </div>
                            <div class="search-form">
                                <div class="row justify-content-end">
                                    <div class="col-8 offset-2 d-flex justify-content-end">
                                        <form action="">
                                            <input type="text" name="search">
                                            <button>Search</button>
                                        </form>
                                    </div>
                                    <div class="col-2">
                                        <div class="social_icons">
                                            <a href="#">
                                                <img class="img-fluid"
                                                    src="http://localhost/projects/RPL/wp-content/themes/akib_rpl/assets/images/facebook-icon.png"
                                                    alt="facebook">
                                            </a>
                                            <a href="#">
                                                <img class="img-fluid"
                                                    src="http://localhost/projects/RPL/wp-content/themes/akib_rpl/assets/images/youtube-icon.png"
                                                    alt="youtube">
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="container">
                <div class="row">
                    <div class="col-12 p-0">

                        <nav class="navbar navbar-expand-lg navbar-light bg-light p-0">
                            <a class="header_logo" href="#">
                                <img class="img-fluid" src="assets/images/logo_en.png" alt="logo_en">
                            </a>
                            <button class="navbar-toggler" type="button" data-toggle="collapse"
                                data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
                                aria-expanded="false" aria-label="Toggle navigation">
                                <span class="navbar-toggler-icon"></span>
                            </button>

                            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                                <ul class="navbar-nav mr-auto">
                                    <div class="menu-main_menu-container">
                                        <ul id="menu-main_menu" class="navbar-nav mr-auto">
                                            <li id="menu-item-18"
                                                class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home current-menu-item page_item page-item-9 current_page_item menu-item-18 nav-item">
                                                <a href="http://localhost/projects/RPL/" aria-current="page"
                                                    class="nav-link">Home</a></li>
                                            <li id="menu-item-19"
                                                class="menu-item menu-item-type-post_type menu-item-object-page current-menu-ancestor current-menu-parent current_page_parent current_page_ancestor menu-item-has-children menu-item-19 nav-item">
                                                <a href="http://localhost/projects/RPL/sample-page/"
                                                    class="nav-link">Sample Page</a>
                                                <ul class="sub-menu">
                                                    <li id="menu-item-20"
                                                        class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home current-menu-item page_item page-item-9 current_page_item menu-item-20 nav-item">
                                                        <a href="http://localhost/projects/RPL/" aria-current="page"
                                                            class="nav-link">Home</a></li>
                                                    <li id="menu-item-21"
                                                        class="menu-item menu-item-type-post_type menu-item-object-page menu-item-21 nav-item">
                                                        <a href="http://localhost/projects/RPL/sample-page/"
                                                            class="nav-link">Sample Page</a></li>
                                                </ul>
                                            </li>
                                            <li id="menu-item-22"
                                                class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home current-menu-item page_item page-item-9 current_page_item menu-item-has-children menu-item-22 nav-item">
                                                <a href="http://localhost/projects/RPL/" aria-current="page"
                                                    class="nav-link">Home</a>
                                                <ul class="sub-menu">
                                                    <li id="menu-item-23"
                                                        class="menu-item menu-item-type-post_type menu-item-object-page menu-item-23 nav-item">
                                                        <a href="http://localhost/projects/RPL/sample-page/"
                                                            class="nav-link">Sample Page</a></li>
                                                </ul>
                                            </li>
                                        </ul>
                                    </div>
                                    <!-- <li class="nav-item active">
                              <a class="nav-link" href="#">Home <span class="sr-only"></span></a>
                            </li>
                            <li class="nav-item">
                              <a class="nav-link" href="#">About Bangladesh</a>
                            </li>
                            <li class="nav-item dropdown">
                              <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                Services
                              </a>
                              <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                                <a class="dropdown-item" href="#">The bangabhaban</a>
                                <a class="dropdown-item" href="#">The national Pirlament</a>
                                <a class="dropdown-item" href="#">Prime minister</a>
                              </div>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="#">Service sector</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="#">Trade & business</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="#">About Bangladesh</a>
                            </li> -->
                                </ul>
                            </div>
                        </nav>
                    </div>
                </div>
            </div>
        </div>
        <section>
            <div class="container">
                <div class="row">
                    <div class="col-8 pl-0">
                        <div class="pm_banner">
                            <img width="1080" height="613"
                                src="http://localhost/projects/RPL/wp-content/uploads/2022/03/National-Portal-Card-PM.jpeg"
                                class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt=""
                                loading="lazy"
                                srcset="http://localhost/projects/RPL/wp-content/uploads/2022/03/National-Portal-Card-PM.jpeg 1080w, http://localhost/projects/RPL/wp-content/uploads/2022/03/National-Portal-Card-PM-300x170.jpeg 300w, http://localhost/projects/RPL/wp-content/uploads/2022/03/National-Portal-Card-PM-1024x581.jpeg 1024w, http://localhost/projects/RPL/wp-content/uploads/2022/03/National-Portal-Card-PM-768x436.jpeg 768w"
                                sizes="(max-width: 1080px) 100vw, 1080px" />
                        </div>
                        <div class="marque slider">
                            <div class="m-slide">
                                <!-- <h4> -->
                                <marquee direction="left" scrollamount="4">

                                    নো মাস্ক নো সার্ভিস। করোনাভাইরাসের বিস্তার রোধে এখনই ডাউনলোড করুন Corona Tracer BD
                                    অ্যাপ। ডাউনলোড করতে ক্লিক করুন <a href="https://bit.ly/coronatracerbd"
                                        target="_blank" rel="noopener">https://bit.ly/coronatracerbd</a>। নিজে সুরক্ষিত
                                    থাকুন অন্যকেও নিরাপদ রাখুন। দেশের প্রথম ক্রাউডফান্ডিং প্ল্যাটফর্ম
                                    &#8216;একদেশ&#8217;- এর মাধ্যমে আর্থিক অনুদান পৌঁছে দিন নির্বাচিত সরকারি-বেসরকারি
                                    প্রতিষ্ঠানসমূহে। ভিজিট করুন <a href="//ekdesh.ekpay.gov.bd" target="_blank"
                                        rel="noopener">ekdesh.ekpay.gov.bd</a> অথবা <a
                                        href="//play.google.com/store/apps/details?id=com.synesis.donationapp"
                                        target="_blank" rel="noopener">“Ek Desh”</a> অ্যাপ ডাউনলোড করুন। করোনার লক্ষণ
                                    দেখা দিলে গোপন না করে ডাক্তারের পরামর্শের জন্য ফ্রি কল করুন ৩৩৩ ও ১৬২৬৩ নম্বরে।
                                    করোনাভাইরাস প্রতিরোধে নিয়ম মেনে মাস্ক ব্যবহার করুন। আতঙ্কিত না হয়ে বরং সচেতন থাকুন।
                                    ভিজিট করুন <a href="//corona.gov.bd" target="_blank"
                                        rel="noopener">corona.gov.bd</a>



                                    <p></p>
                                </marquee>
                                <!-- </h4> -->
                            </div>
                        </div>
                        <div class="slider">
                            <div id="carouselExampleControls" class="carousel slide" data-ride="carousel">
                                <div class="carousel-inner">
                                    <!-- <div class="carousel-item active"> -->
                                    <div class="carousel-item ">
                                        <img width="1400" height="500"
                                            src="http://localhost/projects/RPL/wp-content/uploads/2022/03/Banner-2.jpg"
                                            class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt=""
                                            loading="lazy"
                                            srcset="http://localhost/projects/RPL/wp-content/uploads/2022/03/Banner-2.jpg 1400w, http://localhost/projects/RPL/wp-content/uploads/2022/03/Banner-2-300x107.jpg 300w, http://localhost/projects/RPL/wp-content/uploads/2022/03/Banner-2-1024x366.jpg 1024w, http://localhost/projects/RPL/wp-content/uploads/2022/03/Banner-2-768x274.jpg 768w"
                                            sizes="(max-width: 1400px) 100vw, 1400px" />
                                    </div>
                                    <div class="carousel-item active">
                                        <img width="1400" height="500"
                                            src="http://localhost/projects/RPL/wp-content/uploads/2022/03/Banner-1.jpg"
                                            class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt=""
                                            loading="lazy"
                                            srcset="http://localhost/projects/RPL/wp-content/uploads/2022/03/Banner-1.jpg 1400w, http://localhost/projects/RPL/wp-content/uploads/2022/03/Banner-1-300x107.jpg 300w, http://localhost/projects/RPL/wp-content/uploads/2022/03/Banner-1-1024x366.jpg 1024w, http://localhost/projects/RPL/wp-content/uploads/2022/03/Banner-1-768x274.jpg 768w"
                                            sizes="(max-width: 1400px) 100vw, 1400px" />
                                    </div>
                                    <div class="carousel-item ">
                                        <img width="684" height="220"
                                            src="http://localhost/projects/RPL/wp-content/uploads/2022/03/333_gov.png"
                                            class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt=""
                                            loading="lazy"
                                            srcset="http://localhost/projects/RPL/wp-content/uploads/2022/03/333_gov.png 684w, http://localhost/projects/RPL/wp-content/uploads/2022/03/333_gov-300x96.png 300w"
                                            sizes="(max-width: 684px) 100vw, 684px" />
                                    </div>
                                    <div class="carousel-item ">
                                        <img width="2560" height="1305"
                                            src="http://localhost/projects/RPL/wp-content/uploads/2022/03/4-02-scaled.jpg"
                                            class="attachment-post-thumbnail size-post-thumbnail wp-post-image" alt=""
                                            loading="lazy"
                                            srcset="http://localhost/projects/RPL/wp-content/uploads/2022/03/4-02-scaled.jpg 2560w, http://localhost/projects/RPL/wp-content/uploads/2022/03/4-02-300x153.jpg 300w, http://localhost/projects/RPL/wp-content/uploads/2022/03/4-02-1024x522.jpg 1024w, http://localhost/projects/RPL/wp-content/uploads/2022/03/4-02-768x391.jpg 768w, http://localhost/projects/RPL/wp-content/uploads/2022/03/4-02-1536x783.jpg 1536w, http://localhost/projects/RPL/wp-content/uploads/2022/03/4-02-2048x1044.jpg 2048w"
                                            sizes="(max-width: 2560px) 100vw, 2560px" />
                                    </div>
                                    <a class="carousel-control-prev" href="#carouselExampleControls" role="button"
                                        data-slide="prev">
                                        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                                        <span class="sr-only">Previous</span>
                                    </a>
                                    <a class="carousel-control-next" href="#carouselExampleControls" role="button"
                                        data-slide="next">
                                        <span class="carousel-control-next-icon" aria-hidden="true"></span>
                                        <span class="sr-only">Next</span>
                                    </a>
                                </div>
                            </div>
                        </div>
                        <div class="col-12">
                            <div class="tab_section">
                                <div class="container">
                                    <div class="row flex-column">
                                        <!-- tab buttons -->
                                        <ul class="nav nav-tabs">

                                            <li>
                                                <a data-toggle="tab" class="active" href="#cat1">Category 1</a>
                                            </li>
                                            <li>
                                                <a data-toggle="tab" class="no" href="#cat2">Category 2</a>
                                            </li>
                                            <li>
                                                <a data-toggle="tab" class="no" href="#cat3">Category 3</a>
                                            </li>
                                            <li>
                                                <a data-toggle="tab" class="no" href="#cat4">Category 4</a>
                                            </li>
                                            <li>
                                                <a data-toggle="tab" class="no" href="#cat5">Category 5</a>
                                            </li>
                                        </ul>
                                        <!-- tab content start -->
                                        <div class="tab-content">
                                            <div id="cat1" class="tab-pane fade active show">
                                                <div class="row">
                                                    <div class="col-2">
                                                        <p>The National Parliament</p>
                                                        <img width="1400" height="500"
                                                            src="http://localhost/projects/RPL/wp-content/uploads/2022/03/Banner-2.jpg"
                                                            class="attachment-post-thumbnail size-post-thumbnail wp-post-image"
                                                            alt="" loading="lazy"
                                                            srcset="http://localhost/projects/RPL/wp-content/uploads/2022/03/Banner-2.jpg 1400w, http://localhost/projects/RPL/wp-content/uploads/2022/03/Banner-2-300x107.jpg 300w, http://localhost/projects/RPL/wp-content/uploads/2022/03/Banner-2-1024x366.jpg 1024w, http://localhost/projects/RPL/wp-content/uploads/2022/03/Banner-2-768x274.jpg 768w"
                                                            sizes="(max-width: 1400px) 100vw, 1400px" />
                                                    </div>
                                                    <div class="col-2">
                                                        <p>PM</p>
                                                    </div>
                                                    <div class="col-2">
                                                        <p>All tabs categories</p>
                                                    </div>
                                                    <div class="col-2">
                                                        <p>Tab post 5</p>
                                                        <img width="293" height="74"
                                                            src="http://localhost/projects/RPL/wp-content/uploads/2022/02/logo_bn.png"
                                                            class="attachment-post-thumbnail size-post-thumbnail wp-post-image"
                                                            alt="গণপ্রজাতন্ত্রী বাংলাদেশ" loading="lazy" />
                                                    </div>
                                                    <div class="col-2">
                                                        <p>Tab post 2</p>
                                                        <img width="789" height="134"
                                                            src="http://localhost/projects/RPL/wp-content/uploads/2022/02/Tamplate_govtjob_bn.png"
                                                            class="attachment-post-thumbnail size-post-thumbnail wp-post-image"
                                                            alt="" loading="lazy"
                                                            srcset="http://localhost/projects/RPL/wp-content/uploads/2022/02/Tamplate_govtjob_bn.png 789w, http://localhost/projects/RPL/wp-content/uploads/2022/02/Tamplate_govtjob_bn-300x51.png 300w, http://localhost/projects/RPL/wp-content/uploads/2022/02/Tamplate_govtjob_bn-768x130.png 768w"
                                                            sizes="(max-width: 789px) 100vw, 789px" />
                                                    </div>
                                                    <div class="col-2">
                                                        <p>Tab post 1</p>
                                                        <img width="1400" height="500"
                                                            src="http://localhost/projects/RPL/wp-content/uploads/2022/03/Banner-1.jpg"
                                                            class="attachment-post-thumbnail size-post-thumbnail wp-post-image"
                                                            alt="" loading="lazy"
                                                            srcset="http://localhost/projects/RPL/wp-content/uploads/2022/03/Banner-1.jpg 1400w, http://localhost/projects/RPL/wp-content/uploads/2022/03/Banner-1-300x107.jpg 300w, http://localhost/projects/RPL/wp-content/uploads/2022/03/Banner-1-1024x366.jpg 1024w, http://localhost/projects/RPL/wp-content/uploads/2022/03/Banner-1-768x274.jpg 768w"
                                                            sizes="(max-width: 1400px) 100vw, 1400px" />
                                                    </div>
                                                </div>
                                            </div>
                                            <div id="cat2" class="tab-pane fade ">
                                                <div class="row">
                                                    <div class="col-2">
                                                        <p>PM</p>
                                                    </div>
                                                    <div class="col-2">
                                                        <p>All tabs categories</p>
                                                    </div>
                                                    <div class="col-2">
                                                        <p>Tab post 2</p>
                                                        <img width="789" height="134"
                                                            src="http://localhost/projects/RPL/wp-content/uploads/2022/02/Tamplate_govtjob_bn.png"
                                                            class="attachment-post-thumbnail size-post-thumbnail wp-post-image"
                                                            alt="" loading="lazy"
                                                            srcset="http://localhost/projects/RPL/wp-content/uploads/2022/02/Tamplate_govtjob_bn.png 789w, http://localhost/projects/RPL/wp-content/uploads/2022/02/Tamplate_govtjob_bn-300x51.png 300w, http://localhost/projects/RPL/wp-content/uploads/2022/02/Tamplate_govtjob_bn-768x130.png 768w"
                                                            sizes="(max-width: 789px) 100vw, 789px" />
                                                    </div>
                                                </div>
                                            </div>
                                            <div id="cat3" class="tab-pane fade ">
                                                <div class="row">
                                                    <div class="col-2">
                                                        <p>The National Parliament</p>
                                                        <img width="1400" height="500"
                                                            src="http://localhost/projects/RPL/wp-content/uploads/2022/03/Banner-2.jpg"
                                                            class="attachment-post-thumbnail size-post-thumbnail wp-post-image"
                                                            alt="" loading="lazy"
                                                            srcset="http://localhost/projects/RPL/wp-content/uploads/2022/03/Banner-2.jpg 1400w, http://localhost/projects/RPL/wp-content/uploads/2022/03/Banner-2-300x107.jpg 300w, http://localhost/projects/RPL/wp-content/uploads/2022/03/Banner-2-1024x366.jpg 1024w, http://localhost/projects/RPL/wp-content/uploads/2022/03/Banner-2-768x274.jpg 768w"
                                                            sizes="(max-width: 1400px) 100vw, 1400px" />
                                                    </div>
                                                    <div class="col-2">
                                                        <p>All tabs categories</p>
                                                    </div>
                                                    <div class="col-2">
                                                        <p>Tab post 5</p>
                                                        <img width="293" height="74"
                                                            src="http://localhost/projects/RPL/wp-content/uploads/2022/02/logo_bn.png"
                                                            class="attachment-post-thumbnail size-post-thumbnail wp-post-image"
                                                            alt="গণপ্রজাতন্ত্রী বাংলাদেশ" loading="lazy" />
                                                    </div>
                                                    <div class="col-2">
                                                        <p>Tab post 3</p>
                                                    </div>
                                                </div>
                                            </div>
                                            <div id="cat4" class="tab-pane fade ">
                                                <div class="row">
                                                    <div class="col-2">
                                                        <p>All tabs categories</p>
                                                    </div>
                                                    <div class="col-2">
                                                        <p>Tab post 2</p>
                                                        <img width="789" height="134"
                                                            src="http://localhost/projects/RPL/wp-content/uploads/2022/02/Tamplate_govtjob_bn.png"
                                                            class="attachment-post-thumbnail size-post-thumbnail wp-post-image"
                                                            alt="" loading="lazy"
                                                            srcset="http://localhost/projects/RPL/wp-content/uploads/2022/02/Tamplate_govtjob_bn.png 789w, http://localhost/projects/RPL/wp-content/uploads/2022/02/Tamplate_govtjob_bn-300x51.png 300w, http://localhost/projects/RPL/wp-content/uploads/2022/02/Tamplate_govtjob_bn-768x130.png 768w"
                                                            sizes="(max-width: 789px) 100vw, 789px" />
                                                    </div>
                                                </div>
                                            </div>
                                            <div id="cat5" class="tab-pane fade ">
                                                <div class="row">
                                                    <div class="col-2">
                                                        <p>The National Parliament</p>
                                                        <img width="1400" height="500"
                                                            src="http://localhost/projects/RPL/wp-content/uploads/2022/03/Banner-2.jpg"
                                                            class="attachment-post-thumbnail size-post-thumbnail wp-post-image"
                                                            alt="" loading="lazy"
                                                            srcset="http://localhost/projects/RPL/wp-content/uploads/2022/03/Banner-2.jpg 1400w, http://localhost/projects/RPL/wp-content/uploads/2022/03/Banner-2-300x107.jpg 300w, http://localhost/projects/RPL/wp-content/uploads/2022/03/Banner-2-1024x366.jpg 1024w, http://localhost/projects/RPL/wp-content/uploads/2022/03/Banner-2-768x274.jpg 768w"
                                                            sizes="(max-width: 1400px) 100vw, 1400px" />
                                                    </div>
                                                    <div class="col-2">
                                                        <p>All tabs categories</p>
                                                    </div>
                                                    <div class="col-2">
                                                        <p>Tab post 3</p>
                                                    </div>
                                                    <div class="col-2">
                                                        <p>Tab post 1</p>
                                                        <img width="1400" height="500"
                                                            src="http://localhost/projects/RPL/wp-content/uploads/2022/03/Banner-1.jpg"
                                                            class="attachment-post-thumbnail size-post-thumbnail wp-post-image"
                                                            alt="" loading="lazy"
                                                            srcset="http://localhost/projects/RPL/wp-content/uploads/2022/03/Banner-1.jpg 1400w, http://localhost/projects/RPL/wp-content/uploads/2022/03/Banner-1-300x107.jpg 300w, http://localhost/projects/RPL/wp-content/uploads/2022/03/Banner-1-1024x366.jpg 1024w, http://localhost/projects/RPL/wp-content/uploads/2022/03/Banner-1-768x274.jpg 768w"
                                                            sizes="(max-width: 1400px) 100vw, 1400px" />
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="bottom-widgets">
                            <div class="row">
                                <div class="col-4">
                                    <div id="block-14" class="widget_block">
                                        <figure
                                            class="wp-block-embed is-type-video is-provider-youtube wp-block-embed-youtube wp-embed-aspect-16-9 wp-has-aspect-ratio">
                                            <div class="wp-block-embed__wrapper">
                                                <iframe loading="lazy" title="আশ্রয়ণের অধিকার শেখ হাসিনার উপহার"
                                                    width="500" height="281"
                                                    src="https://www.youtube.com/embed/l7G3TPz6P24?feature=oembed"
                                                    frameborder="0"
                                                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                                                    allowfullscreen></iframe>
                                            </div>
                                        </figure>
                                    </div>
                                </div>
                                <div class="col-4">
                                    <div id="block-15" class="widget_block">
                                        <figure
                                            class="wp-block-embed is-type-video is-provider-youtube wp-block-embed-youtube wp-embed-aspect-16-9 wp-has-aspect-ratio">
                                            <div class="wp-block-embed__wrapper">
                                                <iframe loading="lazy" title="আশ্রয়ণের অধিকার শেখ হাসিনার উপহার"
                                                    width="500" height="281"
                                                    src="https://www.youtube.com/embed/l7G3TPz6P24?feature=oembed"
                                                    frameborder="0"
                                                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                                                    allowfullscreen></iframe>
                                            </div>
                                        </figure>
                                    </div>
                                </div>
                                <div class="col-4">
                                    <div id="block-16" class="widget_block">
                                        <figure
                                            class="wp-block-embed is-type-video is-provider-youtube wp-block-embed-youtube wp-embed-aspect-16-9 wp-has-aspect-ratio">
                                            <div class="wp-block-embed__wrapper">
                                                <iframe loading="lazy" title="আশ্রয়ণের অধিকার শেখ হাসিনার উপহার"
                                                    width="500" height="281"
                                                    src="https://www.youtube.com/embed/l7G3TPz6P24?feature=oembed"
                                                    frameborder="0"
                                                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                                                    allowfullscreen></iframe>
                                            </div>
                                        </figure>
                                    </div>
                                </div>
                                <div class="col-4">
                                    <div id="block-17" class="widget_block">
                                        <figure
                                            class="wp-block-embed is-type-video is-provider-youtube wp-block-embed-youtube wp-embed-aspect-16-9 wp-has-aspect-ratio">
                                            <div class="wp-block-embed__wrapper">
                                                <iframe loading="lazy" title="আশ্রয়ণের অধিকার শেখ হাসিনার উপহার"
                                                    width="500" height="281"
                                                    src="https://www.youtube.com/embed/l7G3TPz6P24?feature=oembed"
                                                    frameborder="0"
                                                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                                                    allowfullscreen></iframe>
                                            </div>
                                        </figure>
                                    </div>
                                </div>
                                <div class="col-4">
                                    <div id="block-18" class="widget_block">
                                        <figure
                                            class="wp-block-embed is-type-video is-provider-youtube wp-block-embed-youtube wp-embed-aspect-16-9 wp-has-aspect-ratio">
                                            <div class="wp-block-embed__wrapper">
                                                <iframe loading="lazy" title="আশ্রয়ণের অধিকার শেখ হাসিনার উপহার"
                                                    width="500" height="281"
                                                    src="https://www.youtube.com/embed/l7G3TPz6P24?feature=oembed"
                                                    frameborder="0"
                                                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                                                    allowfullscreen></iframe>
                                            </div>
                                        </figure>
                                    </div>
                                </div>
                                <div class="col-4">
                                    <div id="block-19" class="widget_block">
                                        <figure
                                            class="wp-block-embed is-type-video is-provider-youtube wp-block-embed-youtube wp-embed-aspect-16-9 wp-has-aspect-ratio">
                                            <div class="wp-block-embed__wrapper">
                                                <iframe loading="lazy" title="আশ্রয়ণের অধিকার শেখ হাসিনার উপহার"
                                                    width="500" height="281"
                                                    src="https://www.youtube.com/embed/l7G3TPz6P24?feature=oembed"
                                                    frameborder="0"
                                                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                                                    allowfullscreen></iframe>
                                            </div>
                                        </figure>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-4 ">
                        <div class="right_widgets">
                            <div id="block-7" class="widget_block widget_media_image">
                                <figure class="wp-block-image size-full"><img loading="lazy" width="293" height="74"
                                        src="http://localhost/projects/RPL/wp-content/uploads/2022/02/logo_bn.png"
                                        alt="গণপ্রজাতন্ত্রী বাংলাদেশ" class="wp-image-5" /></figure>
                            </div>
                            <div id="block-8" class="widget_block widget_media_image">
                                <figure class="wp-block-image size-full"><img loading="lazy" width="222" height="68"
                                        src="http://localhost/projects/RPL/wp-content/uploads/2022/02/ebook_bangla-1.png"
                                        alt="" class="wp-image-24" /></figure>
                            </div>
                            <div id="block-9" class="widget_block widget_media_image">
                                <figure class="wp-block-image size-full"><img loading="lazy" width="789" height="134"
                                        src="http://localhost/projects/RPL/wp-content/uploads/2022/02/Jonotar-Sorkar-banner-Bangla.png"
                                        alt="" class="wp-image-25"
                                        srcset="http://localhost/projects/RPL/wp-content/uploads/2022/02/Jonotar-Sorkar-banner-Bangla.png 789w, http://localhost/projects/RPL/wp-content/uploads/2022/02/Jonotar-Sorkar-banner-Bangla-300x51.png 300w, http://localhost/projects/RPL/wp-content/uploads/2022/02/Jonotar-Sorkar-banner-Bangla-768x130.png 768w"
                                        sizes="(max-width: 789px) 100vw, 789px" /></figure>
                            </div>
                            <div id="block-10" class="widget_block widget_media_image">
                                <figure class="wp-block-image size-full"><img loading="lazy" width="789" height="134"
                                        src="http://localhost/projects/RPL/wp-content/uploads/2022/02/Tamplate_govtjob_bn.png"
                                        alt="" class="wp-image-26"
                                        srcset="http://localhost/projects/RPL/wp-content/uploads/2022/02/Tamplate_govtjob_bn.png 789w, http://localhost/projects/RPL/wp-content/uploads/2022/02/Tamplate_govtjob_bn-300x51.png 300w, http://localhost/projects/RPL/wp-content/uploads/2022/02/Tamplate_govtjob_bn-768x130.png 768w"
                                        sizes="(max-width: 789px) 100vw, 789px" /></figure>
                            </div>
                            <div id="block-11" class="widget_block">
                                <figure
                                    class="wp-block-embed is-type-video is-provider-youtube wp-block-embed-youtube wp-embed-aspect-16-9 wp-has-aspect-ratio">
                                    <div class="wp-block-embed__wrapper">
                                        <iframe loading="lazy" title="আশ্রয়ণের অধিকার শেখ হাসিনার উপহার" width="500"
                                            height="281"
                                            src="https://www.youtube.com/embed/l7G3TPz6P24?start=2&feature=oembed"
                                            frameborder="0"
                                            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                                            allowfullscreen></iframe>
                                    </div>
                                </figure>
                            </div>
                            <div id="block-13" class="widget_block widget_media_image">
                                <figure class="wp-block-image size-full"><img loading="lazy" width="789" height="134"
                                        src="http://localhost/projects/RPL/wp-content/uploads/2022/02/Jonotar-Sorkar-banner-Bangla.png"
                                        alt="" class="wp-image-25"
                                        srcset="http://localhost/projects/RPL/wp-content/uploads/2022/02/Jonotar-Sorkar-banner-Bangla.png 789w, http://localhost/projects/RPL/wp-content/uploads/2022/02/Jonotar-Sorkar-banner-Bangla-300x51.png 300w, http://localhost/projects/RPL/wp-content/uploads/2022/02/Jonotar-Sorkar-banner-Bangla-768x130.png 768w"
                                        sizes="(max-width: 789px) 100vw, 789px" /></figure>
                            </div>
                            <div id="block-12" class="widget_block widget_media_image">
                                <figure class="wp-block-image size-full"><img loading="lazy" width="789" height="134"
                                        src="http://localhost/projects/RPL/wp-content/uploads/2022/02/Tamplate_govtjob_bn.png"
                                        alt="" class="wp-image-26"
                                        srcset="http://localhost/projects/RPL/wp-content/uploads/2022/02/Tamplate_govtjob_bn.png 789w, http://localhost/projects/RPL/wp-content/uploads/2022/02/Tamplate_govtjob_bn-300x51.png 300w, http://localhost/projects/RPL/wp-content/uploads/2022/02/Tamplate_govtjob_bn-768x130.png 768w"
                                        sizes="(max-width: 789px) 100vw, 789px" /></figure>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>


        <footer>
            <div>
                <div class="container">
                    <div id="footer_wrapper" class="row">
                        <div class="col-12">
                            <div class="footer_img"
                                style="background-image: url('http://localhost/projects/RPL/wp-content/themes/akib_rpl/assets/images/footer_top_bg.png');">
                            </div>
                        </div>
                        <div class="col-7">
                            <div class="footer_menu">
                                <ul class="list-none">
                                    <div class="footer_list">
                                        <div class="menu-footer_menu-container">
                                            <ul id="menu-footer_menu" class="d-flex">
                                                <li id="menu-item-41"
                                                    class="menu-item menu-item-type-custom menu-item-object-custom menu-item-41">
                                                    <a href="#">Footer 1</a></li>
                                                <li id="menu-item-42"
                                                    class="menu-item menu-item-type-custom menu-item-object-custom menu-item-42">
                                                    <a href="#">Footer 2</a></li>
                                                <li id="menu-item-43"
                                                    class="menu-item menu-item-type-custom menu-item-object-custom menu-item-43">
                                                    <a href="#">Footer 3</a></li>
                                            </ul>
                                        </div>
                                    </div>
                                </ul>
                            </div>
                            <div class="note">
                                <p>Site was last updated: 2022-02-23 11:32:14</p>
                            </div>
                        </div>
                        <div class="col-5 ">
                            <div class="sup d-flex justify-content-end">
                                <p>Planning and Implementation: a2i, Cabinet Division, BCC, BASIS, DOICT</p>
                            </div>
                            <div class="d-flex justify-content-end align-items-center">
                                <p>Technical Support: </p>
                                <div class="tech_sup">
                                    <img class="img-fluid"
                                        src="http://localhost/projects/RPL/wp-content/themes/akib_rpl/assets/images/np-logo-set.png"
                                        alt="logo_set">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </footer>
    </div>

</body>

</html>